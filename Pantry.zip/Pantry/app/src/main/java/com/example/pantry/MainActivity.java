package com.example.pantry;

import android.os.Bundle;
import android.widget.EditText;
import android.widget.TextView;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import java.io.IOException;

public class MainActivity extends AppCompatActivity {

    ItemDatabase itmData;
    private EditText mFoodItem;
    private TextView mFoodItemTextView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        mFoodItem = findViewById(R.id.FoodItem);
        mFoodItemTextView = findViewById(R.id.itemList);

        findViewById(R.id.addButton).setOnClickListener(view -> addButtonClick());
        itmData = new ItemDatabase(this);
    }

    @Override
    protected void onResume() {
        super.onResume();

        try {
            itmData.readData();
            displayList();
        }
        catch (IOException ex) {
            ex.printStackTrace();
        }
    }

    private void addButtonClick() {
        String item = mFoodItem.getText().toString().trim();

        mFoodItem.setText("");
        itmData.addItem(item);
    }

    private void displayList() {
        itmData.showList();
    }



}