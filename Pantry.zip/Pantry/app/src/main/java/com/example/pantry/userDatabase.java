package com.example.pantry;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

public class userDatabase extends SQLiteOpenHelper {

    private static final String DATABASE_NAME = "users.db";
    private static final int VERSION = 1;

    public userDatabase(Context context) {
        super(context, DATABASE_NAME, null, VERSION);
    }

    private static final class UserTable {
        private static final String TABLE= "Users";
        private static final String COL_ID = "_id";
        private static final String COL_UserName = "username";
        private static final String COL_Password = "password";
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        db.execSQL("create table " + UserTable.TABLE + " (" +
                UserTable.COL_ID + " integer primary key autoincrement, " +
                UserTable.COL_UserName + " text, " +
                UserTable.COL_Password + " text )");

    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {

        db.execSQL("drop table if exists " + UserTable.TABLE);
        onCreate(db);
    }

    public boolean checkUser(String userName, String Password) {
        SQLiteDatabase db = getReadableDatabase();

        String userN = "select * from " + UserTable.TABLE + " where username = " + userName;
        Cursor cursor = db.rawQuery(userN, new String[] { userName });
        if (cursor.moveToFirst()) {
            do {
                String checkName = cursor.getString(2);
                String checkPass = cursor.getString(3);
                int checkID = cursor.getInt(0);

                if (userName == checkName) {
                    if (Password == checkPass) {
                        return true;
                    }
                }
            } while (cursor.moveToNext());
        }
        cursor.close();
        return false;
    }

    public void createNewUser(String userName, String Password) {
        SQLiteDatabase db = getWritableDatabase();

        ContentValues values = new ContentValues();
        values.put(UserTable.COL_UserName, userName);
        values.put(UserTable.COL_Password, Password);

        db.insert(UserTable.TABLE, null, values);
        return;
    }
}
