package com.example.pantry;

import android.content.Intent;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;


public class LoginActivity extends AppCompatActivity {

    userDatabase usrData = new userDatabase(this);

    private EditText mUserName;
    private EditText mPassword;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);
        mUserName = findViewById(R.id.editTextUsername);
        mPassword = findViewById(R.id.editTextPassword);

    }


    public void onLoginClick(View view) {
        if (usrData.checkUser(mUserName.toString(), mPassword.toString())) {
            Intent intent = new Intent(this, MainActivity.class);
        }
        else {
            usrData.createNewUser(mUserName.toString(), mPassword.toString());
        }
    }

    public void onNewUserClick(View view) {
        usrData.createNewUser(mUserName.toString(), mPassword.toString());
    }
}