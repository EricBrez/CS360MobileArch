package com.example.pantry;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

public class ItemDatabase extends SQLiteOpenHelper {
    private static final String DATABASE_NAME = "items.db";
    private static final int VERSION = 1;

    public ItemDatabase(Context context) {
        super(context, DATABASE_NAME, null, VERSION);
    }

    private static final class ItemTable {
        private static final String TABLE = "Items";
        private static final String COL_ID = "_id";
        private static final String COL_Item = "ItemName";
        private static final String COL_Quantity = "Count";
    }

    @Override
    public void onCreate (SQLiteDatabase db) {
        db.execSQL("create table " + ItemTable.TABLE + " (" +
                ItemTable.COL_ID + " integer primary key autoincrement, " +
                ItemTable.COL_Item + " text, " +
                ItemTable.COL_Quantity + " integer)");
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion,
                          int newVersion) {
        db.execSQL("drop table if exists " + ItemTable.TABLE);
        onCreate(db);
    }

    public String addItem(String Item) {
        SQLiteDatabase db = getWritableDatabase();

        ContentValues values = new ContentValues();
        values.put(ItemTable.COL_Item, Item);
        values.put(ItemTable.COL_Quantity, 1);

        String newItem = String.valueOf(db.insert(ItemTable.TABLE, null, values));
        return newItem;
    }

    public String editItem(int id, Integer count) {
        SQLiteDatabase db = getWritableDatabase();

        ContentValues values = new ContentValues();
        values.put(ItemTable.COL_Quantity, count);

        String newItem = String.valueOf(db.update(ItemTable.TABLE, values, "_id = ?",
                new String[] {Integer.toString(id) }));

        return newItem;
    }

    public void removeItem(String Item) {
        SQLiteDatabase db = getWritableDatabase();

        db.delete(ItemTable.TABLE, ItemTable.COL_Item + " = ?",
                new String[] {Item});
    }

    public void showList() {
        SQLiteDatabase db = getReadableDatabase();

        String sql = "select * from " + ItemTable.TABLE;
        Cursor cursor = db.rawQuery(sql, new String[] {ItemTable.COL_Quantity});

        if (cursor.moveToFirst()) {
            do {
                int id = cursor.getInt(1);
                String item = cursor.getString(2);
                int count = cursor.getInt(3);
            } while (cursor.moveToNext());
        }
        cursor.close();
    }

    public void readData() {
        SQLiteDatabase db = getReadableDatabase();

        String sql = "select * from " + ItemTable.TABLE;
        Cursor cursor = db.rawQuery(sql, new String[] {ItemTable.COL_Quantity});}


}
